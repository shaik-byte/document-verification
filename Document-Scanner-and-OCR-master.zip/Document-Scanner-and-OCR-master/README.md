# Document Scanner and OCR

1. Document Scanner using opencv and perspective transform
2. OCR using tesseract

courtesy: pyimagesearch.com
